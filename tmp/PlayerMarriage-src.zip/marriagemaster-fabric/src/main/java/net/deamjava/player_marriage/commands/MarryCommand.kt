package net.deamjava.player_marriage.commands

import com.mojang.brigadier.CommandDispatcher
import com.mojang.brigadier.arguments.StringArgumentType
import net.deamjava.player_marriage.data.MarriageData
import net.deamjava.player_marriage.data.PendingProposal
import net.deamjava.player_marriage.util.Msg
import net.minecraft.command.CommandRegistryAccess
import net.minecraft.command.argument.EntityArgumentType
import net.minecraft.registry.RegistryKey
import net.minecraft.server.command.CommandManager
import net.minecraft.server.command.ServerCommandSource
import net.minecraft.server.network.ServerPlayerEntity
import net.minecraft.text.ClickEvent
import net.minecraft.text.Text
import net.minecraft.util.Formatting
import net.minecraft.world.TeleportTarget
import net.minecraft.world.World
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.abs

object MarryCommand {

    private val DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").withZone(ZoneId.systemDefault())

    fun register(dispatcher: CommandDispatcher<ServerCommandSource>) {
        dispatcher.register(
            CommandManager.literal("marry")
                // /marry help
                .executes { ctx -> showHelp(ctx.source) }
                .then(CommandManager.literal("help")
                    .executes { ctx -> showHelp(ctx.source) })

                // /marry <player>  – propose
                .then(CommandManager.argument("player", EntityArgumentType.player())
                    .executes { ctx ->
                        val target = EntityArgumentType.getPlayer(ctx, "player")
                        propose(ctx.source, target)
                    })

                // /marry accept
                .then(CommandManager.literal("accept")
                    .executes { ctx -> acceptProposal(ctx.source) })

                // /marry deny
                .then(CommandManager.literal("deny")
                    .executes { ctx -> denyProposal(ctx.source) })

                // /marry divorce
                .then(CommandManager.literal("divorce")
                    .executes { ctx -> divorce(ctx.source) })

                // /marry tp
                .then(CommandManager.literal("tp")
                    .executes { ctx -> teleportToPartner(ctx.source) })

                // /marry sethome
                .then(CommandManager.literal("sethome")
                    .executes { ctx -> setHome(ctx.source) })

                // /marry home
                .then(CommandManager.literal("home")
                    .executes { ctx -> goHome(ctx.source) })

                // /marry delhome
                .then(CommandManager.literal("delhome")
                    .executes { ctx -> delHome(ctx.source) })

                // /marry gift
                .then(CommandManager.literal("gift")
                    .executes { ctx -> gift(ctx.source) })

                // /marry chat [message]
                .then(CommandManager.literal("chat")
                    .executes { ctx -> toggleChat(ctx.source) }
                    .then(CommandManager.argument("message", StringArgumentType.greedyString())
                        .executes { ctx ->
                            val msg = StringArgumentType.getString(ctx, "message")
                            sendPartnerChat(ctx.source, msg)
                        }))

                // /marry kiss
                .then(CommandManager.literal("kiss")
                    .executes { ctx -> kissCommand(ctx.source) })

                // /marry hug
                .then(CommandManager.literal("hug")
                    .executes { ctx -> hug(ctx.source) })

                // /marry pvpon
                .then(CommandManager.literal("pvpon")
                    .executes { ctx -> setPvp(ctx.source, false) })

                // /marry pvpoff
                .then(CommandManager.literal("pvpoff")
                    .executes { ctx -> setPvp(ctx.source, true) })

                // /marry seen
                .then(CommandManager.literal("seen")
                    .executes { ctx -> seen(ctx.source) })

                // /marry list
                .then(CommandManager.literal("list")
                    .executes { ctx -> list(ctx.source) })
        )
    }

    // ─── /marry help ─────────────────────────────────────────────────────────

    private fun showHelp(source: ServerCommandSource): Int {
        source.sendFeedback({
            Text.literal("")
                .append(Text.literal("━━━ ").formatted(Formatting.DARK_GRAY))
                .append(Text.literal("❤ PlayerMarriage ❤").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD))
                .append(Text.literal(" ━━━\n").formatted(Formatting.DARK_GRAY))
                .append(helpLine("/marry <player>", "Propose to a player"))
                .append(helpLine("/marry accept / deny", "Accept or deny a proposal"))
                .append(helpLine("/marry divorce", "Divorce your partner"))
                .append(helpLine("/marry tp", "Teleport to partner"))
                .append(helpLine("/marry sethome", "Set your couple's home"))
                .append(helpLine("/marry home", "Teleport to couple's home"))
                .append(helpLine("/marry delhome", "Delete couple's home"))
                .append(helpLine("/marry gift", "Give held item to partner"))
                .append(helpLine("/marry chat [msg]", "Toggle/send private chat"))
                .append(helpLine("/mc <msg>", "Quick private chat message"))
                .append(helpLine("/marry kiss", "Kiss your partner ❤"))
                .append(helpLine("/marry hug", "Hug your partner"))
                .append(helpLine("/marry pvpon/off", "Toggle PvP protection"))
                .append(helpLine("/marry seen", "When was partner last online"))
                .append(helpLine("/marry list", "List all couples"))
                .append(Text.literal("  Shift + Right-click").formatted(Formatting.YELLOW))
                .append(Text.literal(" your partner to kiss them!\n").formatted(Formatting.GRAY))
        }, false)
        return 1
    }

    private fun helpLine(cmd: String, desc: String): Text =
        Text.literal("  ").append(Text.literal(cmd).formatted(Formatting.YELLOW))
            .append(Text.literal(" - ").formatted(Formatting.DARK_GRAY))
            .append(Text.literal("$desc\n").formatted(Formatting.GRAY))

    // ─── /marry <player> ─────────────────────────────────────────────────────

    private fun propose(source: ServerCommandSource, target: ServerPlayerEntity): Int {
        val proposer = source.playerOrThrow
        if (proposer.uuid == target.uuid) {
            proposer.sendMessage(Msg.error("You can't marry yourself!"))
            return 0
        }
        if (MarriageData.isMarried(proposer.uuidAsString)) {
            proposer.sendMessage(Msg.error("You are already married! Divorce first."))
            return 0
        }
        if (MarriageData.isMarried(target.uuidAsString)) {
            proposer.sendMessage(Msg.error("${target.name.string} is already married!"))
            return 0
        }
        if (MarriageData.getProposal(target.uuidAsString) != null) {
            proposer.sendMessage(Msg.error("${target.name.string} already has a pending proposal."))
            return 0
        }

        val proposal = PendingProposal(
            proposerUuid = proposer.uuidAsString,
            proposerName = proposer.name.string,
            targetUuid = target.uuidAsString
        )
        MarriageData.addProposal(proposal)

        // Tell proposer
        proposer.sendMessage(
            Msg.heart("You proposed to ").append(Text.literal(target.name.string).formatted(Formatting.LIGHT_PURPLE))
                .append(Msg.heart("! Waiting for their response..."))
        )

        // Tell target with clickable buttons
        val acceptBtn = Text.literal("[Accept]").formatted(Formatting.GREEN, Formatting.BOLD)
            .styled { it.withClickEvent(ClickEvent(ClickEvent.Action.RUN_COMMAND, "/marry accept")) }
        val denyBtn = Text.literal("[Deny]").formatted(Formatting.RED, Formatting.BOLD)
            .styled { it.withClickEvent(ClickEvent(ClickEvent.Action.RUN_COMMAND, "/marry deny")) }

        target.sendMessage(
            Text.literal("")
                .append(Text.literal("❤ ").formatted(Formatting.LIGHT_PURPLE))
                .append(Text.literal(proposer.name.string).formatted(Formatting.YELLOW))
                .append(Text.literal(" has proposed to you! ").formatted(Formatting.WHITE))
                .append(acceptBtn)
                .append(Text.literal(" "))
                .append(denyBtn)
        )

        return 1
    }

    // ─── /marry accept ───────────────────────────────────────────────────────

    private fun acceptProposal(source: ServerCommandSource): Int {
        val player = source.playerOrThrow
        val proposal = MarriageData.getProposal(player.uuidAsString)
        if (proposal == null) {
            player.sendMessage(Msg.error("You have no pending proposal."))
            return 0
        }

        // Check proposal not stale (5 min timeout)
        if (Instant.now().epochSecond - proposal.timestamp > 300) {
            MarriageData.removeProposal(player.uuidAsString)
            player.sendMessage(Msg.error("That proposal has expired."))
            return 0
        }

        val proposer = MarriageData.getOnlinePlayer(proposal.proposerUuid)
        if (proposer == null) {
            MarriageData.removeProposal(player.uuidAsString)
            player.sendMessage(Msg.error("${proposal.proposerName} is no longer online."))
            return 0
        }

        MarriageData.removeProposal(player.uuidAsString)
        MarriageData.marry(proposer, player)

        // Announce to server
        val announcement = Text.literal("")
            .append(Text.literal("❤ ").formatted(Formatting.LIGHT_PURPLE))
            .append(Text.literal(proposer.name.string).formatted(Formatting.YELLOW))
            .append(Text.literal(" and ").formatted(Formatting.WHITE))
            .append(Text.literal(player.name.string).formatted(Formatting.YELLOW))
            .append(Text.literal(" are now married! Congratulations! ❤").formatted(Formatting.LIGHT_PURPLE))

        source.server.playerManager.playerList.forEach { it.sendMessage(announcement) }
        return 1
    }

    // ─── /marry deny ─────────────────────────────────────────────────────────

    private fun denyProposal(source: ServerCommandSource): Int {
        val player = source.playerOrThrow
        val proposal = MarriageData.getProposal(player.uuidAsString)
        if (proposal == null) {
            player.sendMessage(Msg.error("You have no pending proposal."))
            return 0
        }
        MarriageData.removeProposal(player.uuidAsString)
        player.sendMessage(Msg.info("You denied the proposal."))

        val proposer = MarriageData.getOnlinePlayer(proposal.proposerUuid)
        proposer?.sendMessage(Msg.error("${player.name.string} denied your proposal. 💔"))
        return 1
    }

    // ─── /marry divorce ──────────────────────────────────────────────────────

    private val pendingDivorce = mutableSetOf<String>()

    private fun divorce(source: ServerCommandSource): Int {
        val player = source.playerOrThrow
        if (!MarriageData.isMarried(player.uuidAsString)) {
            player.sendMessage(Msg.error("You are not married."))
            return 0
        }
        if (!pendingDivorce.contains(player.uuidAsString)) {
            pendingDivorce.add(player.uuidAsString)
            player.sendMessage(
                Text.literal("⚠ Are you sure you want to divorce? ").formatted(Formatting.YELLOW)
                    .append(Text.literal("[Confirm]").formatted(Formatting.RED, Formatting.BOLD)
                        .styled { it.withClickEvent(ClickEvent(ClickEvent.Action.RUN_COMMAND, "/marry divorce")) })
            )
            // auto-remove confirmation after 30s
            Thread {
                Thread.sleep(30_000)
                pendingDivorce.remove(player.uuidAsString)
            }.also { it.isDaemon = true }.start()
            return 1
        }

        pendingDivorce.remove(player.uuidAsString)
        val partnerUuid = MarriageData.getPartnerUuid(player.uuidAsString)!!
        val partnerName = MarriageData.getPartnerName(player.uuidAsString)!!
        MarriageData.divorce(player.uuidAsString, partnerUuid)

        val announcement = Text.literal("")
            .append(Text.literal("💔 ").formatted(Formatting.RED))
            .append(Text.literal(player.name.string).formatted(Formatting.YELLOW))
            .append(Text.literal(" and ").formatted(Formatting.GRAY))
            .append(Text.literal(partnerName).formatted(Formatting.YELLOW))
            .append(Text.literal(" have divorced. 💔").formatted(Formatting.RED))

        source.server.playerManager.playerList.forEach { it.sendMessage(announcement) }

        val partner = MarriageData.getOnlinePlayer(partnerUuid)
        partner?.sendMessage(Msg.error("${player.name.string} has divorced you."))
        return 1
    }

    // ─── /marry tp ───────────────────────────────────────────────────────────

    private fun teleportToPartner(source: ServerCommandSource): Int {
        val player = source.playerOrThrow
        if (!MarriageData.isMarried(player.uuidAsString)) {
            player.sendMessage(Msg.error("You are not married."))
            return 0
        }
        val partnerUuid = MarriageData.getPartnerUuid(player.uuidAsString)!!
        val partnerName = MarriageData.getPartnerName(player.uuidAsString)!!
        val partner = MarriageData.getOnlinePlayer(partnerUuid)
        if (partner == null) {
            player.sendMessage(Msg.error("$partnerName is not online."))
            return 0
        }
        player.teleportTo(
            TeleportTarget(
                partner.serverWorld,
                partner.pos,
                partner.velocity,
                partner.yaw,
                partner.pitch,
                TeleportTarget.NO_OP
            )
        )
        player.sendMessage(Msg.heart("Teleported to $partnerName!"))
        partner.sendMessage(Msg.heart("${player.name.string} teleported to you."))
        return 1
    }

    // ─── /marry sethome ──────────────────────────────────────────────────────

    private fun setHome(source: ServerCommandSource): Int {
        val player = source.playerOrThrow
        if (!MarriageData.isMarried(player.uuidAsString)) {
            player.sendMessage(Msg.error("You are not married."))
            return 0
        }
        val dim = player.world.registryKey.value.toString()
        MarriageData.setHome(player.uuidAsString, player.x, player.y, player.z, dim)
        player.sendMessage(Msg.heart("Couple's home set!"))

        val partnerUuid = MarriageData.getPartnerUuid(player.uuidAsString)!!
        MarriageData.getOnlinePlayer(partnerUuid)
            ?.sendMessage(Msg.heart("${player.name.string} set your couple's home."))
        return 1
    }

    // ─── /marry home ─────────────────────────────────────────────────────────

    private fun goHome(source: ServerCommandSource): Int {
        val player = source.playerOrThrow
        if (!MarriageData.isMarried(player.uuidAsString)) {
            player.sendMessage(Msg.error("You are not married."))
            return 0
        }
        if (!MarriageData.hasHome(player.uuidAsString)) {
            player.sendMessage(Msg.error("No couple's home set! Use /marry sethome first."))
            return 0
        }
        val record = MarriageData.getRecord(player.uuidAsString)!!
        val dimKey = net.minecraft.util.Identifier.of(record.homeDimension!!)
        val worldKey = RegistryKey.of(net.minecraft.registry.RegistryKeys.WORLD, dimKey)
        val world = source.server.getWorld(worldKey)
        if (world == null) {
            player.sendMessage(Msg.error("Home dimension is unavailable."))
            return 0
        }
        player.teleportTo(
            TeleportTarget(
                world,
                net.minecraft.util.math.Vec3d(record.homeX!!, record.homeY!!, record.homeZ!!),
                net.minecraft.util.math.Vec3d.ZERO,
                player.yaw,
                player.pitch,
                TeleportTarget.NO_OP
            )
        )
        player.sendMessage(Msg.heart("Teleported to couple's home!"))
        return 1
    }

    // ─── /marry delhome ──────────────────────────────────────────────────────

    private fun delHome(source: ServerCommandSource): Int {
        val player = source.playerOrThrow
        if (!MarriageData.isMarried(player.uuidAsString)) {
            player.sendMessage(Msg.error("You are not married."))
            return 0
        }
        if (!MarriageData.hasHome(player.uuidAsString)) {
            player.sendMessage(Msg.error("No home is set."))
            return 0
        }
        MarriageData.deleteHome(player.uuidAsString)
        player.sendMessage(Msg.heart("Couple's home deleted."))

        val partnerUuid = MarriageData.getPartnerUuid(player.uuidAsString)!!
        MarriageData.getOnlinePlayer(partnerUuid)
            ?.sendMessage(Msg.info("${player.name.string} deleted your couple's home."))
        return 1
    }

    // ─── /marry gift ─────────────────────────────────────────────────────────

    private fun gift(source: ServerCommandSource): Int {
        val player = source.playerOrThrow
        if (!MarriageData.isMarried(player.uuidAsString)) {
            player.sendMessage(Msg.error("You are not married."))
            return 0
        }
        val partnerUuid = MarriageData.getPartnerUuid(player.uuidAsString)!!
        val partnerName = MarriageData.getPartnerName(player.uuidAsString)!!
        val partner = MarriageData.getOnlinePlayer(partnerUuid)
        if (partner == null) {
            player.sendMessage(Msg.error("$partnerName is not online."))
            return 0
        }
        val held = player.mainHandStack
        if (held.isEmpty) {
            player.sendMessage(Msg.error("You're not holding anything!"))
            return 0
        }
        val itemName = held.name.string
        val gift = held.copy()
        player.mainHandStack = net.minecraft.item.ItemStack.EMPTY

        // try to add to partner's inventory, drop at feet if full
        if (!partner.inventory.insertStack(gift)) {
            val dropped = partner.dropItem(gift, false)
            dropped?.setOwner(partner.uuid)
        }

        player.sendMessage(Msg.heart("You gifted $itemName to $partnerName! ❤"))
        partner.sendMessage(
            Text.literal("❤ ").formatted(Formatting.LIGHT_PURPLE)
                .append(Text.literal(player.name.string).formatted(Formatting.YELLOW))
                .append(Text.literal(" gifted you ").formatted(Formatting.WHITE))
                .append(Text.literal(itemName).formatted(Formatting.AQUA))
                .append(Text.literal("!").formatted(Formatting.WHITE))
        )
        return 1
    }

    // ─── /marry chat ─────────────────────────────────────────────────────────

    private fun toggleChat(source: ServerCommandSource): Int {
        val player = source.playerOrThrow
        if (!MarriageData.isMarried(player.uuidAsString)) {
            player.sendMessage(Msg.error("You are not married."))
            return 0
        }
        val on = MarriageData.chatToggled.contains(player.uuidAsString)
        if (on) {
            MarriageData.chatToggled.remove(player.uuidAsString)
            player.sendMessage(Msg.info("Private chat disabled. Talking to everyone now."))
        } else {
            MarriageData.chatToggled.add(player.uuidAsString)
            player.sendMessage(Msg.heart("Private chat enabled! Only your partner will see your messages."))
        }
        return 1
    }

    fun sendPartnerChat(source: ServerCommandSource, message: String): Int {
        val player = source.playerOrThrow
        if (!MarriageData.isMarried(player.uuidAsString)) {
            player.sendMessage(Msg.error("You are not married."))
            return 0
        }
        val partnerUuid = MarriageData.getPartnerUuid(player.uuidAsString)!!
        val partnerName = MarriageData.getPartnerName(player.uuidAsString)!!
        val partner = MarriageData.getOnlinePlayer(partnerUuid)

        val chatMsg = Text.literal("")
            .append(Text.literal("❤ [Private] ").formatted(Formatting.LIGHT_PURPLE))
            .append(Text.literal(player.name.string).formatted(Formatting.YELLOW))
            .append(Text.literal(": ").formatted(Formatting.WHITE))
            .append(Text.literal(message).formatted(Formatting.WHITE))

        player.sendMessage(chatMsg)
        if (partner == null) {
            player.sendMessage(Msg.info("($partnerName is offline — message not delivered)"))
        } else {
            partner.sendMessage(chatMsg)
        }
        return 1
    }

    // ─── /marry kiss ─────────────────────────────────────────────────────────

    fun kissCommand(source: ServerCommandSource): Int {
        val player = source.playerOrThrow
        if (!MarriageData.isMarried(player.uuidAsString)) {
            player.sendMessage(Msg.error("You are not married."))
            return 0
        }
        val partnerUuid = MarriageData.getPartnerUuid(player.uuidAsString)!!
        val partnerName = MarriageData.getPartnerName(player.uuidAsString)!!
        val partner = MarriageData.getOnlinePlayer(partnerUuid)
        if (partner == null) {
            player.sendMessage(Msg.error("$partnerName is not online."))
            return 0
        }
        spawnKissEffects(player, partner)
        return 1
    }

    fun spawnKissEffects(player: ServerPlayerEntity, partner: ServerPlayerEntity) {
        val partnerName = partner.name.string
        val playerName = player.name.string

        // Spawn heart particles at both players
        listOf(player, partner).forEach { p ->
            p.serverWorld.spawnParticles(
                net.minecraft.particle.ParticleTypes.HEART,
                p.x, p.y + 2.2, p.z,
                8, 0.3, 0.3, 0.3, 0.05
            )
        }

        // Action bar to partner
        partner.sendMessage(
            Text.literal("❤ $playerName kissed you! ❤").formatted(Formatting.LIGHT_PURPLE),
            true
        )
        player.sendMessage(
            Text.literal("❤ You kissed $partnerName! ❤").formatted(Formatting.LIGHT_PURPLE),
            true
        )

        // Sound
        player.serverWorld.playSound(
            null,
            player.blockPos,
            net.minecraft.sound.SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP,
            net.minecraft.sound.SoundCategory.PLAYERS,
            0.5f, 1.8f
        )
    }

    // ─── /marry hug ──────────────────────────────────────────────────────────

    private fun hug(source: ServerCommandSource): Int {
        val player = source.playerOrThrow
        if (!MarriageData.isMarried(player.uuidAsString)) {
            player.sendMessage(Msg.error("You are not married."))
            return 0
        }
        val partnerUuid = MarriageData.getPartnerUuid(player.uuidAsString)!!
        val partnerName = MarriageData.getPartnerName(player.uuidAsString)!!
        val partner = MarriageData.getOnlinePlayer(partnerUuid)
        if (partner == null) {
            player.sendMessage(Msg.error("$partnerName is not online."))
            return 0
        }

        partner.sendMessage(
            Text.literal("🤗 ${player.name.string} hugged you!").formatted(Formatting.YELLOW),
            true
        )
        player.sendMessage(
            Text.literal("🤗 You hugged $partnerName!").formatted(Formatting.YELLOW),
            true
        )

        // Puff particles
        player.serverWorld.spawnParticles(
            net.minecraft.particle.ParticleTypes.HAPPY_VILLAGER,
            player.x, player.y + 1.0, player.z,
            12, 0.5, 0.5, 0.5, 0.05
        )
        return 1
    }

    // ─── /marry pvpon/off ────────────────────────────────────────────────────

    private fun setPvp(source: ServerCommandSource, protect: Boolean): Int {
        val player = source.playerOrThrow
        if (!MarriageData.isMarried(player.uuidAsString)) {
            player.sendMessage(Msg.error("You are not married."))
            return 0
        }
        MarriageData.setPvpProtected(player.uuidAsString, protect)
        val status = if (protect) "OFF (protected)" else "ON"
        player.sendMessage(Msg.info("PvP with your partner is now $status."))
        return 1
    }

    // ─── /marry seen ─────────────────────────────────────────────────────────

    private fun seen(source: ServerCommandSource): Int {
        val player = source.playerOrThrow
        if (!MarriageData.isMarried(player.uuidAsString)) {
            player.sendMessage(Msg.error("You are not married."))
            return 0
        }
        val partnerUuid = MarriageData.getPartnerUuid(player.uuidAsString)!!
        val partnerName = MarriageData.getPartnerName(player.uuidAsString)!!

        val online = MarriageData.getOnlinePlayer(partnerUuid)
        if (online != null) {
            player.sendMessage(Msg.heart("$partnerName is currently online!"))
        } else {
            val lastSeen = MarriageData.getLastSeen(partnerUuid)
            if (lastSeen == null) {
                player.sendMessage(Msg.info("$partnerName has never been seen online."))
            } else {
                val formatted = DATE_FMT.format(Instant.ofEpochSecond(lastSeen))
                player.sendMessage(Msg.info("$partnerName was last seen on $formatted."))
            }
        }
        return 1
    }

    // ─── /marry list ─────────────────────────────────────────────────────────

    private fun list(source: ServerCommandSource): Int {
        val couples = MarriageData.getAllCouples()
        if (couples.isEmpty()) {
            source.sendFeedback({ Msg.info("No couples are registered yet.") }, false)
            return 1
        }
        source.sendFeedback({
            val text = Text.literal("━━━ ").formatted(Formatting.DARK_GRAY)
                .append(Text.literal("❤ Married Couples ❤").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD))
                .append(Text.literal(" ━━━\n").formatted(Formatting.DARK_GRAY))
            couples.forEachIndexed { i, record ->
                text.append(
                    Text.literal("  ${i + 1}. ").formatted(Formatting.DARK_GRAY)
                        .append(Text.literal(record.player1Name).formatted(Formatting.YELLOW))
                        .append(Text.literal(" ❤ ").formatted(Formatting.LIGHT_PURPLE))
                        .append(Text.literal(record.player2Name).formatted(Formatting.YELLOW))
                        .append(Text.literal("\n"))
                )
            }
            text
        }, false)
        return 1
    }
}
