package net.deamjava.player_marriage.commands

import com.mojang.brigadier.CommandDispatcher
import com.mojang.brigadier.arguments.StringArgumentType
import net.minecraft.server.command.CommandManager
import net.minecraft.server.command.ServerCommandSource

object McCommand {
    fun register(dispatcher: CommandDispatcher<ServerCommandSource>) {
        dispatcher.register(
            CommandManager.literal("mc")
                .then(CommandManager.argument("message", StringArgumentType.greedyString())
                    .executes { ctx ->
                        val msg = StringArgumentType.getString(ctx, "message")
                        MarryCommand.sendPartnerChat(ctx.source, msg)
                    })
        )
    }
}
