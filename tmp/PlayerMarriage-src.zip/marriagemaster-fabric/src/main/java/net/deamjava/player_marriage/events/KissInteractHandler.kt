package net.deamjava.player_marriage.events

import net.deamjava.player_marriage.commands.MarryCommand
import net.deamjava.player_marriage.data.MarriageData
import net.deamjava.player_marriage.util.Msg
import net.fabricmc.fabric.api.event.player.UseEntityCallback
import net.minecraft.entity.player.PlayerEntity
import net.minecraft.server.network.ServerPlayerEntity
import net.minecraft.util.ActionResult
import java.time.Instant

object KissInteractHandler {

    // uuid -> last kiss timestamp (for cooldown)
    private val kissCooldowns = mutableMapOf<String, Long>()
    private const val COOLDOWN_SECONDS = 5L

    fun register() {
        UseEntityCallback.EVENT.register { player, world, hand, entity, _ ->
            if (world.isClient) return@register ActionResult.PASS
            if (!player.isSneaking) return@register ActionResult.PASS
            if (entity !is PlayerEntity) return@register ActionResult.PASS

            val serverPlayer = player as? ServerPlayerEntity ?: return@register ActionResult.PASS
            val targetPlayer = entity as? ServerPlayerEntity ?: return@register ActionResult.PASS

            if (!MarriageData.isMarried(serverPlayer.uuidAsString)) return@register ActionResult.PASS

            val partnerUuid = MarriageData.getPartnerUuid(serverPlayer.uuidAsString)
            if (partnerUuid != targetPlayer.uuidAsString) return@register ActionResult.PASS

            // Cooldown check
            val now = Instant.now().epochSecond
            val lastKiss = kissCooldowns[serverPlayer.uuidAsString] ?: 0L
            if (now - lastKiss < COOLDOWN_SECONDS) {
                val remaining = COOLDOWN_SECONDS - (now - lastKiss)
                serverPlayer.sendMessage(
                    Msg.info("Wait ${remaining}s before kissing again!"),
                    true
                )
                return@register ActionResult.SUCCESS
            }

            kissCooldowns[serverPlayer.uuidAsString] = now
            MarryCommand.spawnKissEffects(serverPlayer, targetPlayer)
            ActionResult.SUCCESS
        }
    }
}
