package net.deamjava.player_marriage.events

import net.deamjava.player_marriage.data.MarriageData
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents
import net.minecraft.server.network.ServerPlayerEntity
import net.minecraft.text.Text
import net.minecraft.util.Formatting

object ChatHandler {

    fun register() {
        // Allow-all check: if player has chat toggled on, we want to redirect.
        // We use ServerMessageEvents.ALLOW_CHAT_MESSAGE to cancel the public message,
        // then manually deliver it to the partner only.
        ServerMessageEvents.ALLOW_CHAT_MESSAGE.register { message, sender, _ ->
            val player = sender as? ServerPlayerEntity ?: return@register true
            if (!MarriageData.chatToggled.contains(player.uuidAsString)) return@register true

            if (!MarriageData.isMarried(player.uuidAsString)) {
                MarriageData.chatToggled.remove(player.uuidAsString)
                return@register true
            }

            val partnerUuid = MarriageData.getPartnerUuid(player.uuidAsString)!!
            val partner = MarriageData.getOnlinePlayer(partnerUuid)

            val chatMsg = Text.literal("")
                .append(Text.literal("❤ [Private] ").formatted(Formatting.LIGHT_PURPLE))
                .append(Text.literal(player.name.string).formatted(Formatting.YELLOW))
                .append(Text.literal(": ").formatted(Formatting.WHITE))
                .append(Text.literal(message.content.string).formatted(Formatting.WHITE))

            player.sendMessage(chatMsg)
            partner?.sendMessage(chatMsg) ?: player.sendMessage(
                Text.literal("(Partner is offline)").formatted(Formatting.GRAY)
            )

            false // cancel public broadcast
        }
    }
}
