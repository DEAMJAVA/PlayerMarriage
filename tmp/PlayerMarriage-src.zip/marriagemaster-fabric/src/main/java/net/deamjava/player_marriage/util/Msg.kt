package net.deamjava.player_marriage.util

import net.minecraft.text.MutableText
import net.minecraft.text.Text
import net.minecraft.util.Formatting

object Msg {
    fun error(msg: String): MutableText =
        Text.literal("✗ ").formatted(Formatting.RED)
            .append(Text.literal(msg).formatted(Formatting.RED))

    fun info(msg: String): MutableText =
        Text.literal("ℹ ").formatted(Formatting.GRAY)
            .append(Text.literal(msg).formatted(Formatting.GRAY))

    fun heart(msg: String): MutableText =
        Text.literal("❤ ").formatted(Formatting.LIGHT_PURPLE)
            .append(Text.literal(msg).formatted(Formatting.WHITE))
}
