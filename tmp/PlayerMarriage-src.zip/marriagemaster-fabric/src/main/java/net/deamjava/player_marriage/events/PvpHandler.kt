package net.deamjava.player_marriage.events

import net.deamjava.player_marriage.data.MarriageData
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents
import net.minecraft.entity.damage.DamageSource
import net.minecraft.server.network.ServerPlayerEntity

object PvpHandler {

    fun register() {
        // We use a mixin for damage cancellation (see PlayerEntityMixin.java)
        // This object exists so we can expose the check logic cleanly
    }

    /**
     * Called from the mixin. Returns true if the attack should be cancelled.
     */
    fun shouldCancelDamage(victim: ServerPlayerEntity, source: DamageSource): Boolean {
        val attacker = source.attacker
        if (attacker !is ServerPlayerEntity) return false
        if (!MarriageData.isMarried(victim.uuidAsString)) return false

        val partnerUuid = MarriageData.getPartnerUuid(victim.uuidAsString) ?: return false
        if (partnerUuid != attacker.uuidAsString) return false

        // Cancel only if BOTH players have pvp protection toggled
        return MarriageData.isPvpProtected(victim.uuidAsString) &&
               MarriageData.isPvpProtected(attacker.uuidAsString)
    }
}
